-- MySQL dump 10.17  Distrib 10.3.22-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: mysql
-- ------------------------------------------------------
-- Server version	10.3.22-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `help_category`
--

DROP TABLE IF EXISTS `help_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `help_category` (
  `help_category_id` smallint(5) unsigned NOT NULL,
  `name` char(64) NOT NULL,
  `parent_category_id` smallint(5) unsigned DEFAULT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`help_category_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='help categories';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `help_category`
--

LOCK TABLES `help_category` WRITE;
/*!40000 ALTER TABLE `help_category` DISABLE KEYS */;
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (1,'Geographic',0,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (2,'Polygon properties',34,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (3,'WKT',34,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (4,'Numeric Functions',38,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (5,'Plugins',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (6,'MBR',34,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (7,'Control flow functions',38,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (8,'Transactions',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (9,'Help Metadata',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (10,'Account Management',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (11,'Point properties',34,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (12,'Encryption Functions',38,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (13,'LineString properties',34,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (14,'Miscellaneous Functions',38,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (15,'Logical operators',38,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (16,'Functions and Modifiers for Use with GROUP BY',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (17,'Information Functions',38,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (18,'Comparison operators',38,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (19,'Bit Functions',38,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (20,'Table Maintenance',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (21,'User-Defined Functions',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (22,'Data Types',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (23,'Compound Statements',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (24,'Geometry constructors',34,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (25,'GeometryCollection properties',1,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (26,'Administration',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (27,'Data Manipulation',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (28,'Utility',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (29,'Language Structure',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (30,'Geometry relations',34,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (31,'Date and Time Functions',38,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (32,'WKB',34,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (33,'Procedures',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (34,'Geographic Features',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (35,'Contents',0,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (36,'Geometry properties',34,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (37,'String Functions',38,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (38,'Functions',35,'');
INSERT  IGNORE INTO `help_category` (`help_category_id`, `name`, `parent_category_id`, `url`) VALUES (39,'Data Definition',35,'');
/*!40000 ALTER TABLE `help_category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-13  4:41:41
